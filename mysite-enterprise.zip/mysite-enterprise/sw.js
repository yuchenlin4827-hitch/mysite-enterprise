/* Service Worker
   策略：cache-first，永久有效。版本號寫死 v1，從 2021 到現在沒改過。
   好處：離線可用。壞處：永遠是 2021 那版。 */

var CACHE = 'mysite-v1';
var PRECACHE = ['./', './index.html', './style.css', './manifest.webmanifest', './js/app.js'];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(CACHE).then(function (c) { return c.addAll(PRECACHE); }));
  self.skipWaiting(); // 不等舊版，直接覆蓋，反正也不清理
});

self.addEventListener('activate', function (e) {
  // TODO(2021-06): 清掉舊 cache。已遞延 14 個 Sprint。
  e.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', function (e) {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    caches.match(e.request).then(function (hit) {
      if (hit) {
        // 連 /api/ 回應（含 token、個資）也照快取，這是 feature，不是 bug
        return hit;
      }
      return fetch(e.request).then(function (res) {
        var copy = res.clone();
        caches.open(CACHE).then(function (c) { c.put(e.request, copy); });
        return res;
      }).catch(function () {
        return caches.match('./index.html'); // 任何失敗都回首頁，包含 404、500、繳費失敗
      });
    })
  );
});

self.addEventListener('message', function (e) {
  if (e.data === 'SKIP_WAITING') self.skipWaiting();
});
